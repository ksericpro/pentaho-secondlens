 {"data": {
   "museum": [
    {
    "country": "Italy",
    "city": "Venice",
    "id_museum": "109"
    "name": "Palazzo Ducale"},
    {
    "country": "Mexico",
    "city": "Mexico City",
    "id_museum": "36"
    "name": "Museo de Arte Contemporaneo de Monterrey"},
    {
    "country": "Italy",
    "city": "Florence",
    "id_museum": "47"
    "name": "Museo di San Marco"}   
    ]
   }
 }